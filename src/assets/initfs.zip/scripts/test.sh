alert Scripted2!
markdown /docs/README.md
