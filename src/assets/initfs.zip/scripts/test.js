kernel.execute('alert Scripted!')
kernel.execute('snackbar Hey!')
terminal.log('Man, this is swell.')
